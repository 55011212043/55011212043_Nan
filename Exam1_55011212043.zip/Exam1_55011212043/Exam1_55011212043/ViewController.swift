//
//  ViewController.swift
//  Exam1_55011212043
//
//  Created by iStudents on 3/13/15.
//  Copyright (c) 2015 iStudents. All rights reserved.
//

import UIKit
class ViewController: UIViewController{

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        refreshUI()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBOutlet weak var Subjectname: UITextField!
    @IBOutlet weak var MidFullTotal: UITextField!
    @IBOutlet weak var MidTotal: UITextField!
    @IBOutlet weak var FinFullTotal: UITextField!
    @IBOutlet weak var FinTotal: UITextField!
    @IBOutlet weak var FullTotal: UITextField!
    @IBOutlet weak var Total: UITextField!
    @IBOutlet weak var textView: UITextView!
    
    
    @IBAction func viewTapped(sender: AnyObject) {
        MidFullTotal.resignFirstResponder()
        MidTotal.resignFirstResponder()
        FinFullTotal.resignFirstResponder()
        FinTotal.resignFirstResponder()
        FullTotal.resignFirstResponder()
        Total.resignFirstResponder()
    }

    func checkFullTotal(mid:Int, finale:Int, total:Int)->Bool{
        
        let sum=mid+finale+total
        
        if sum != 100 {
            return false
        }else{
            return true
        }
        
    }
    
    func checkScore(mid:Double, finale:Double, total:Double)->Bool{
        var tmid=Double((MidFullTotal.text as NSString).integerValue)
        var tfin=Double((FinFullTotal.text as NSString).integerValue)
        var tto=Double((FullTotal.text as NSString).integerValue)
        if mid > tmid {
            return false
        }else if finale > tfin {
            return false
        }else if total > tto {
            return false
        }else {
            return true
        }
    }

    @IBAction func Calulate(sender: AnyObject) {
        var tmid=Int((MidFullTotal.text as NSString).integerValue)
        var tfin=Int((FinFullTotal.text as NSString).integerValue)
        var tto=Int((FullTotal.text as NSString).integerValue)
        
        let ch = checkFullTotal(tmid, finale: tfin, total: tto)
        var txt=""
        if ch==false{
            let message="คะแนนเต็มต้องรวมทั้งหมด 100 คะแนน"
            let alert = UIAlertController(title: "Something Wrong!", message: message, preferredStyle: UIAlertControllerStyle.Alert)
            
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.Default, handler: {
                (alert:UIAlertAction!) in println("An alert of type \(alert.style.hashValue) was tapped!")
            }))
            self.presentViewController(alert,animated: true, completion: nil)
            
        }else{
            var subject=String(Subjectname.text as NSString)
            var midtotal=Double((MidTotal.text as NSString).doubleValue)
            var fintotal=Double((FinTotal.text as NSString).doubleValue)
            var ttotal=Double((Total.text as NSString).doubleValue)
            
            let chNum = checkScore(midtotal, finale: fintotal, total: ttotal)
            
            if chNum==false{
                let message="คะแนนที่ได้จะต้องได้ไม่เกินคะแนนเต็ม"
                let alert = UIAlertController(title: "Something Wrong!", message: message, preferredStyle: UIAlertControllerStyle.Alert)
                
                alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.Default, handler: {
                    (alert:UIAlertAction!) in println("An alert of type \(alert.style.hashValue) was tapped!")
                }))
                self.presentViewController(alert,animated: true, completion: nil)
            }else{
                var summ=midtotal+fintotal+ttotal
                
                if summ >= 80{
                    txt="A"
                }else if summ >= 74 {
                    txt="B+"
                }else if summ >= 68 {
                    txt="B"
                }else if summ >= 62 {
                    txt="C+"
                }else if summ >= 56 {
                    txt="C"
                }else if summ >= 50 {
                    txt="D+"
                }else if summ >= 44 {
                    txt="D"
                }else{
                    txt="F"
                }
                textView.text = String(format: "%0.2f",summ)
                textView.text = "Subject name = \(subject)\nScore = \(summ)\nGrade = \(txt)"
            }
            
        }
    }
    func refreshUI(){
        textView.text=""
        MidTotal.text = String(format: "%0.2f",MidTotal)
        FinTotal.text = String(format: "%0.2f",FinTotal)
        Total.text = String(format: "%0.2f",Total)
        
    }
}

